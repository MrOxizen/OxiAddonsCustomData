<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.6
 */

return array(1.0, 'Beaver Builder', true, 'oxi-addons-fl-builder');
