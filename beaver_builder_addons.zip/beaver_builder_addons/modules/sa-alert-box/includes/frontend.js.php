jQuery('document').ready(function(){

jQuery('#oxi__alert_<?php echo $id ?> #oxi__cross_<?php echo $id ?>').on('click', function(){
jQuery('#oxi__alert_<?php echo $id ?>').fadeOut();
})
});