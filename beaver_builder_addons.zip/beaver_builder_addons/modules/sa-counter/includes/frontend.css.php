<?php

/**
 * start coding for fornend for dynamic style
 * @package shortcode addons
 */
 
 