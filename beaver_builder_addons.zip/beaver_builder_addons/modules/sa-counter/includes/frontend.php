<?php
/**
 * @package shortcode addons
 */
// echo '<pre>';
// print_r($settings);
// echo '</pre>';
 
$title = $display_count = '';
 