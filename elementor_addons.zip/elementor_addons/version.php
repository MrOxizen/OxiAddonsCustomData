<?php
/*
  Plugin Name: Shortcode Addons
  Type: Extention
  Name: Elementor Elements
  Version: 1.7.2
 */

return array(1.7 , 'Elementor', true, 'oxi-el-addons');
